<?php

namespace CoinGate\Exception;

class UnknownApiErrorException extends ApiErrorException
{
}
