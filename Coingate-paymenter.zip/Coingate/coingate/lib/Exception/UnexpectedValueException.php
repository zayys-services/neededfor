<?php

namespace CoinGate\Exception;

class UnexpectedValueException extends \UnexpectedValueException
{
}
